/*Add your JavaScript here*/

/*other variables*/
var defenseScore = 0;
var prosecutionScore = 0;
var questionCount = 0;

var result = document.getElementById("result");
var restart = document.getElementById("restart");

/*button variables*/
var q1a1 = document.getElementById("q1a1");
var q1a2 = document.getElementById("q1a2");
var q2a1 = document.getElementById("q2a1");
var q2a2 = document.getElementById("q2a2");
var q3a1 = document.getElementById("q3a1");
var q3a2 = document.getElementById("q3a2");
var q4a1 = document.getElementById("q4a1");
var q4a2 = document.getElementById("q4a2");
var q5a1 = document.getElementById("q5a1");
var q5a2 = document.getElementById("q5a2");

/*event listeners*/
q1a1.addEventListener("click", defense);
q1a2.addEventListener("click", prosecution);

q2a1.addEventListener("click", prosecution);
q2a2.addEventListener("click", defense);

q3a1.addEventListener("click", prosecution);
q3a2.addEventListener("click", defense);

q4a1.addEventListener("click", defense);
q4a2.addEventListener("click", prosecution);

q5a1.addEventListener("click", prosecution);
q5a2.addEventListener("click", defense);

restart.addEventListener("click", restartQuiz);

/*functions*/
/*points toward defense*/
function defense (){
  defenseScore += 1;
  questionCount += 1;
  console.log("questionCount=" + questionCount + "defenseScore=" + defenseScore);

  /*check if all questions were answered*/
  if(questionCount == 5){
    console.log("The quiz is done!");
    updateResult();
    }
}

/*points toward prosecution*/
function prosecution (){
  prosecutionScore += 1;
  questionCount += 1;
  console.log("questionCount=" + questionCount + "prosecutionScore=" + prosecutionScore)

  /*check if all questions were answered*/
  if(questionCount == 5){
    console.log("The quiz is done!");
    updateResult();
    }
}

/*calculate result based on points*/
function updateResult(){
  if (defenseScore >= 3) {
    result.innerHTML = "You are a defense attorney! Known as the paragons of mercy, defense attorneys are quick thinkers and good at seeing every angle. They have unshakeable faith in the goodness of their clients (and people), and they thrive in chaos.";
    console.log("You are a defense attorney.");
    }
  else if (prosecutionScore >= 3) {
    result.innerHTML = "You are a prosecutor! Known as the servants of justice, prosecutors are confident, well-prepared, and cautious. They have strong convictions (and morals), and they thrive in routine.";
    console.log("You are a prosecutor.");
    }
}

/*reset the quiz*/
function restartQuiz(){
  //document.getElementById();
  defenseScore = 0;
  prosecutionScore = 0;
  questionCount = 0;
  result.innerHTML = "You are a...";
}
